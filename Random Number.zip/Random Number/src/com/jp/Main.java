package com.jp;

import javax.swing.plaf.TreeUI;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
	// Mini Project in Java
        int finalNumber= (int) (Math.random()*100);
        Scanner scanner = new Scanner(System.in);
        int userGuess = 0;
        do{
            System.out.print("Guess the number : ");
            userGuess = scanner.nextInt();
            if(userGuess==finalNumber){
                System.out.println("Great!! You Got it correct");
                break;
            }
            else{
                if (userGuess>finalNumber)
                    System.out.println("Your Number is greater than the correct number");
                else{
                    System.out.println("Your Number is smaller than the correct Number");
                }
            }
        }while (userGuess>=0);
        System.out.println("Guessing Number was : ");
        System.out.println(finalNumber);

    }
}
